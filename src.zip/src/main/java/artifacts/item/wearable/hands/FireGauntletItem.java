package artifacts.item.wearable.hands;

import artifacts.item.wearable.WearableArtifactItem;
import artifacts.registry.ModGameRules;
import artifacts.util.DamageSourceHelper;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;

public class FireGauntletItem extends WearableArtifactItem {

    public FireGauntletItem() {
        MinecraftForge.EVENT_BUS.addListener(this::onLivingHurt);
    }

    @Override
    public boolean hasNonCosmeticEffects() {
        return ModGameRules.FIRE_GAUNTLET_FIRE_DURATION.get() > 0;
    }

    private void onLivingHurt(LivingHurtEvent event) {
        LivingEntity entity = event.getEntity();
        DamageSource damageSource = event.getSource();
        LivingEntity attacker = DamageSourceHelper.getAttacker(damageSource);
        if (isEquippedBy(attacker) && DamageSourceHelper.isMeleeAttack(damageSource) && !entity.fireImmune()) {
            entity.setSecondsOnFire(ModGameRules.FIRE_GAUNTLET_FIRE_DURATION.get() / 20);
        }
    }

    @Override
    public SoundEvent getEquipSound() {
        return SoundEvents.ARMOR_EQUIP_IRON;
    }
}
