package artifacts.client.item.model;

import com.google.common.collect.ImmutableList;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

import java.util.function.Function;

public class HeadModel extends HumanoidModel<LivingEntity> {

    public HeadModel(ModelPart part, Function<ResourceLocation, RenderType> renderType) {
        super(part, renderType);
    }

    public HeadModel(ModelPart part) {
        this(part, RenderType::entityCutoutNoCull);
    }

    @Override
    protected Iterable<ModelPart> headParts() {
        return ImmutableList.of(head);
    }

    @Override
    protected Iterable<ModelPart> bodyParts() {
        return ImmutableList.of();
    }

    public static MeshDefinition createEmptyHat(CubeListBuilder head) {
        MeshDefinition mesh = createMesh(CubeDeformation.NONE, 0);

        mesh.getRoot().addOrReplaceChild(
                "head",
                head,
                PartPose.ZERO
        );

        return mesh;
    }

    public static MeshDefinition createHat(CubeListBuilder head) {
        CubeDeformation deformation = new CubeDeformation(0.51F);

        head.texOffs(0, 0);
        head.addBox(-4, -8, -4, 8, 8, 8, deformation);

        return createEmptyHat(head);
    }

    public static MeshDefinition createDiagonalHat(CubeListBuilder head, CubeListBuilder diagonalParts, String partName) {
        MeshDefinition mesh = createHat(head);

        mesh.getRoot().getChild("head").addOrReplaceChild(
                partName,
                diagonalParts,
                PartPose.rotation(45 * (float) Math.PI / 180, 0, 0)
        );

        return mesh;
    }

    public static MeshDefinition createDrinkingHat() {
        CubeListBuilder head = CubeListBuilder.create();
        CubeListBuilder straws = CubeListBuilder.create();

        // hat shade
        head.texOffs(32, 11);
        head.addBox(-4, -6, -8, 8, 1, 4);

        // cans
        head.texOffs(32, 0);
        head.addBox(4, -11, -1, 3, 6, 3);
        head.texOffs(44, 0);
        head.addBox(-7, -11, -1, 3, 6, 3);

        // middle straw
        head.texOffs(32, 9);
        head.addBox(-6, -1, -5, 12, 1, 1);

        // side straws
        straws.texOffs(0, 16);
        straws.addBox(5, -4, -3, 1, 1, 8);
        straws.texOffs(18, 16);
        straws.addBox(-6, -4, -3, 1, 1, 8);

        return createDiagonalHat(head, straws, "straws");
    }

    public static MeshDefinition createSuperstitiousHat() {
        CubeListBuilder head = CubeListBuilder.create();

        head.texOffs(0, 0);
        head.addBox(-4, -16, -4, 8, 8, 8);
        head.texOffs(0, 16);
        head.addBox(-5, -9, -5, 10, 1, 10);

        return createEmptyHat(head);
    }

    public static MeshDefinition createBrimmedHat(CubeListBuilder head) {
        head.texOffs(0, 16);
        head.addBox(-8, -5.125F, -8, 16, 0, 16);

        return createHat(head);
    }

    public static MeshDefinition createWhoopeeCushion() {
        CubeListBuilder head = CubeListBuilder.create();

        // cushion
        head.texOffs(0, 0);
        head.addBox(-3, -10, -3, 6, 2, 6);

        // flap
        head.texOffs(0, 8);
        head.addBox(-2, -9.25F, 3, 4, 0, 4);

        return createEmptyHat(head);
    }

    public static MeshDefinition createCowboyHat() {
        CubeListBuilder head = CubeListBuilder.create();
        CubeListBuilder leftBrim = CubeListBuilder.create();
        CubeListBuilder rightBrim = CubeListBuilder.create();

        head.texOffs(-16, 16);
        head.addBox(-6, -5.125F, -8, 12, 0, 16);
        leftBrim.texOffs(24 - 16, 16);
        leftBrim.addBox(0, 0, 0, 2, 0, 16);
        rightBrim.texOffs(28 - 16, 16);
        rightBrim.addBox(0, 0, 0, 2, 0, 16);

        MeshDefinition mesh = createHat(head);

        mesh.getRoot().getChild("head").addOrReplaceChild("left_brim", leftBrim,
                PartPose.offsetAndRotation(6, -5.125F, -8, 0, 0, - 45 * (float) Math.PI / 180)
        );
        mesh.getRoot().getChild("head").addOrReplaceChild("right_brim", rightBrim,
                PartPose.offsetAndRotation(-6 - 1.41421F, -5.125F - 1.41421F, -8, 0, 0, 45 * (float) Math.PI / 180)
        );

        return mesh;
    }

    public static MeshDefinition createAnglersHat() {
        CubeListBuilder head = CubeListBuilder.create();
        CubeDeformation deformation = new CubeDeformation(0, 0.51F, 0.2505F);

        head.texOffs(24, -4);
        head.addBox(4 + 0.51F, -13.125F - 0.51F, 0.2505F, 0, 8, 4, deformation);

        return createBrimmedHat(head);
    }
}
