package artifacts.client.item.model;

import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.LivingEntity;

public class StarCloakModel extends HumanoidModel<LivingEntity> {

    public StarCloakModel(ModelPart root) {
        super(root, RenderType::entityCutoutNoCull);
    }

    public static MeshDefinition createStarCloak() {
        MeshDefinition mesh = HumanoidModel.createMesh(CubeDeformation.NONE, 0.0F);
        PartDefinition root = mesh.getRoot();
        PartDefinition body = root.getChild("body");

        body.addOrReplaceChild(
                "collar",
                CubeListBuilder.create().texOffs(32, 6).addBox(-5.5F, -1.2F, -2.5F, 11.0F, 4.0F, 5.0F),
                PartPose.offset(0.0F, 0.0F, 2.8F)
        );
        body.addOrReplaceChild(
                "cloak_left",
                CubeListBuilder.create().texOffs(14, 0).addBox(-6.0F, 0.0F, 0.0F, 6.0F, 20.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 0.4F, 2.6F, 0.0436F, -0.0436F, 0.1309F)
        );
        body.addOrReplaceChild(
                "cloak_right",
                CubeListBuilder.create().texOffs(13, 21).addBox(0.0F, 0.0F, 0.0F, 6.0F, 20.0F, 1.0F),
                PartPose.offsetAndRotation(0.0F, 0.4F, 2.6F, 0.0436F, 0.0436F, -0.1309F)
        );
        body.addOrReplaceChild(
                "cloak_center",
                CubeListBuilder.create().texOffs(0, 0).addBox(-2.5F, 0.0F, -1.0F, 5.0F, 20.0F, 2.0F),
                PartPose.offsetAndRotation(0.0F, 0.5F, 3.0F, 0.0872F, 0.0F, 0.0F)
        );
        body.addOrReplaceChild(
                "hood_down",
                CubeListBuilder.create().texOffs(38, 0).addBox(-5.0F, 0.0F, 0.0F, 10.0F, 3.0F, 3.0F),
                PartPose.offset(0.0F, -0.5F, 3.0F)
        );
        root.getChild("head").addOrReplaceChild(
                "hood_up",
                CubeListBuilder.create().texOffs(0, 44).addBox(-5.0F, -9.5F, -5.0F, 10.0F, 10.0F, 10.0F),
                PartPose.ZERO
        );
        return mesh;
    }
}
